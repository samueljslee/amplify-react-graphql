import React, {useState, useEffect } from 'react';
import axios from 'axios';
import { Table } from './components/Table';
import AddRow from './components/AddRow'
import "./styles/App.css";
import "./styles/loader.css";

const App = () => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [filterTags, setFilterTags] = useState([]);
  const [filtiredData, setFiltiredData] = useState([]);


  const tableOptions = ['eds.core_base.domain_lookup', 'eds.core_base.branch_properties', 'esdl.etl.data_classification_exception'];
  const [selectedTable, setSelectedTable] = useState(tableOptions[0]);
       
  // useEffect((tableName) => {
  //   // const url = 'testData.json';
  //   const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api/?table=${tableName}`;
  //   axios.get(url).then((response) => {
  //     setData(response.data);
  //     setFiltiredData(response.data);
  //     setLoading(false);
  //   })
  // }, [tableName]);
  
  const getTable = () => {
    setLoading(true);
    console.log('tableName: ', selectedTable)
    const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api/?table=${selectedTable}`;
    axios.get(url).then((response) => {
      setData(response.data);
      setFiltiredData(response.data);
      setLoading(false);  
    })
  };

  const onEdit = (_row) => {
    setLoading(true);
    // return new Promise((resolve)=> {
    //   // update old row in data
    //   const _data = data.map(
    //     item => JSON.stringify(item) === JSON.stringify(_row.oldRow) ? _row.newRow : item
    //   );
    // });
    const _data = data.map(
      item => JSON.stringify(item) === JSON.stringify(_row.oldRow) ? _row.newRow : item
    );
    console.log('_row: ', _row)
    const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api/${_row['newRow']['ID']}`
    const body = {
      function: "edit",
      FIELD_NAME: _row['newRow']['FIELD_NAME'],
      CODE: _row['newRow']['CODE'],
      LONG_DESCR: _row['newRow']['LONG_DESCR'],
      SHORT_DESCR: _row['newRow']['SHORT_DESCR'],
      NOTES: _row['newRow']['NOTES'],
      SORT_ORDER: _row['newRow']['SORT_ORDER'],
      CODE_NO: _row['newRow']['CODE_NO'],
      OLD_FIELD_NAME: _row['oldRow']['FIELD_NAME'],
      OLD_CODE: _row['oldRow']['CODE'],
      OLD_LONG_DESCR: _row['oldRow']['LONG_DESCR'],
      OLD_SHORT_DESCR: _row['oldRow']['SHORT_DESCR'],
      OLD_NOTES: _row['oldRow']['NOTES'],
      OLD_SORT_ORDER: _row['oldRow']['SORT_ORDER'],
      OLD_CODE_NO: _row['oldRow']['CODE_NO'],
    }
    return axios.post(url, body)
    .then(function (response) {
        setTimeout(() => {
          setData(_data);
          setLoading(false);
          // resolve(true);
        }, 1000);
    })
    .catch(function (error) {
        console.log(error);
    });
  }

  const onDelete = (deletedItem) => {
    setLoading(true);
    // return new Promise((resolve)=> {
    //   // remove old row in data
    //   const _data = data.filter((item => {
    //     return JSON.stringify(item) !== JSON.stringify(deletedItem)
    //   }));
    //   setTimeout(() => {
    //     setData(_data);
    //     setLoading(false);
    //     resolve(true);
    //   }, 1000);
    // });
    const _data = data.filter((item => {
      return JSON.stringify(item) !== JSON.stringify(deletedItem)
    }));
    console.log('deletedItem: ', deletedItem['FIELD_NAME'])
    const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api`
    const body = {
      function: "delete",
      FIELD_NAME: deletedItem['FIELD_NAME'],
      CODE: deletedItem['CODE'],
      LONG_DESCR: deletedItem['LONG_DESCR'],
      SHORT_DESCR: deletedItem['SHORT_DESCR'],
      NOTES: deletedItem['NOTES'],
      SORT_ORDER: deletedItem['SORT_ORDER'],
      CODE_NO: deletedItem['CODE_NO'],
    } 
    console.log('deleteData body: ', body)
    return axios.put(url, body)
    .then(function (response) {
      console.log('DELETE Function Triggered: ', response);
        setTimeout(() => {
        setData(_data);
        setLoading(false);
        // resolve(true);
      }, 1000);
    })
    .catch(function (error) {
      console.log('Delete function error: ', error);
    });
  }

  const getFilteredData = (_data, _filter) => {
    return _data.filter(item => {
      if (item[_filter.filterName] && item[_filter.filterName].toString().includes(_filter.filterInput)) {
        return true;
      } else if (!item[_filter.filterName] && _filter.filterInput === '') {
        return true;
      }
      return false;
    });
  }

  const onFilter = (filter=false) => {
    let _filteredData = filter ? getFilteredData(data, filter) : data;
    if (filterTags) {
      filterTags.forEach(tag => {
        _filteredData = getFilteredData(_filteredData, tag);
      });
    }
    setFiltiredData(_filteredData);
  }

  const onFilterTagsChange = (filterTags) => setFilterTags(filterTags);

  useEffect(() => onFilter(), [filterTags]);



  // const [editFormData, setEditFormData] = useState({
  //   id: "",
  //   fieldName: "",
  //   code: "",
  //   longDesc: "",
  //   shortDesc: "",
  //   notes: "",
  //   sortOrder: "",
  //   codeNo: "",
  //   old_fieldName: "",
  //   old_code: "",
  //   old_longDesc: "",
  //   old_shortDesc: "",
  //   old_notes: "",
  //   old_sortOrder: "",
  //   old_codeNo: "",
  // });

  // const [addFormData, setAddFormData] = useState({
  //   fieldName: "",
  //   code: "",
  //   longDesc: "",
  //   shortDesc: "",
  //   notes: "",
  //   sortOrder: "",
  //   codeNo: "",
  // });

  // const [deleteDataForm, setDeleteData] = useState({
  //   id: "",
  //   fieldName: "",
  //   code: "",
  //   longDesc: "",
  //   shortDesc: "",
  //   notes: "",
  //   sortOrder: "",
  //   codeNo: "",
  // });

  // const [tableOption, setTableOption] = useState("");

  // const [filterOption, setFilterOption] = useState(colNames[0]);

  // const [currentPageNumber, setCurrentPageNumber] = useState(10);

  // const [currentPage, setCurrentPage] = useState(1);

  // const [nPages, setNPages] = useState(1);

  // const [currentRecords, setCurrentRecords] = useState([]);

  // const handleEditFormChange = (event) => {
  //   const fieldValue = event.target.value;
  //   const newFormData = {... editFormData, [event.target.getAttribute("name")] : fieldValue};
  //   setEditFormData(newFormData)
  // }


  // const handleEditClick = (event, user) => {
  //   event.preventDefault();

  //   const formValues = {
  //     id: user.ID,
  //     fieldName: user.FIELD_NAME,
  //     code: user.CODE,
  //     longDesc: user.LONG_DESCR,
  //     shortDesc: user.SHORT_DESCR,
  //     notes: user.NOTES,
  //     sortOrder: user.SORT_ORDER,
  //     codeNo: user.CODE_NO,
  //     old_fieldName: user.FIELD_NAME,
  //     old_code: user.CODE,
  //     old_longDesc: user.LONG_DESCR,
  //     old_shortDesc: user.SHORT_DESCR,
  //     old_notes: user.NOTES,
  //     old_sortOrder: user.SORT_ORDER,
  //     old_codeNo: user.CODE_NO,
  //   };
  //   setEditFormData(formValues);
  // }

  // const postData = async() => {
  //   console.log("editFormData: ", editFormData)
  //   setLoading(true)
  //   const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api/${editFormData.id}`
  //   const body = {
  //     function: "edit",
  //     FIELD_NAME: editFormData.fieldName,
  //     CODE: editFormData.code,
  //     LONG_DESCR: editFormData.longDesc,
  //     SHORT_DESCR: editFormData.shortDesc,
  //     NOTES: editFormData.notes,
  //     SORT_ORDER: editFormData.sortOrder,
  //     CODE_NO: editFormData.codeNo,
  //     OLD_FIELD_NAME: editFormData.old_fieldName,
  //     OLD_CODE: editFormData.old_code,
  //     OLD_LONG_DESCR: editFormData.old_longDesc,
  //     OLD_SHORT_DESCR: editFormData.old_shortDesc,
  //     OLD_NOTES: editFormData.old_notes,
  //     OLD_SORT_ORDER: editFormData.old_sortOrder,
  //     OLD_CODE_NO: editFormData.old_codeNo,
  //   }
  //   return axios.post(url, body)
  //   .then(function (response) {
  //     const newRow = {
  //       CODE: editFormData.code,
  //       CODE_NO: editFormData.codeNo,
  //       FIELD_NAME: editFormData.fieldName,
  //       ID: editFormData.id,
  //       LONG_DESCR: editFormData.longDesc,
  //       NOTES: editFormData.notes,
  //       SHORT_DESCR: editFormData.shortDesc,
  //       SORT_ORDER: editFormData.sortOrder,
  //     }
  //     console.log('postData: ', data);
  //     const newRowId = data.map((i) => i.ID).indexOf(editFormData.id)
  //     // const _data = data
  //     data[newRowId] = newRow
  //     setData(data);
  //     setEditFormData({id: null})
  //     setLoading(false)
  //   })
  //   .catch(function (error) {
  //     console.log(error);
  //   });
  // }

  const [addFormData, setAddFormData] = useState({
    fieldName: "",
    code: "",
    longDesc: "",
    shortDesc: "",
    notes: "",
    sortOrder: "",
    codeNo: "",
  });
  
  const handleAddFormChange = (event) => {
    event.preventDefault();
    const fieldValue = event.target.value;
    const newFormData = {... addFormData, [event.target.getAttribute("name")] : fieldValue};
    setAddFormData(newFormData)
  }

  const postAddData = async() => {
    setLoading(true)
    console.log("addFormData: ", addFormData)
    const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api`
    const body = {
      function: "add",
      FIELD_NAME: addFormData.fieldName,
      CODE: addFormData.code,
      LONG_DESCR: addFormData.longDesc,
      SHORT_DESCR: addFormData.shortDesc,
      NOTES: addFormData.notes,
      SORT_ORDER: addFormData.sortOrder,
      CODE_NO: addFormData.codeNo,
    }
    return axios.put(url, body)
    .then(function (response) {
      console.log('postAddData response: ', response);
      setAddFormData(null)
      setLoading(false)
    })
    .catch(function (error) {
      console.log('postAddData error: ', error);
    });
  }

  // function setDelete(event, user){
  //   event.preventDefault();
  //   console.log('setDelete user:', user)
  //   const formValues = {
  //     id: user.ID,
  //     fieldName: user.FIELD_NAME,
  //     code: user.CODE,
  //     longDesc: user.LONG_DESCR,
  //     shortDesc: user.SHORT_DESCR,
  //     notes: user.NOTES,
  //     sortOrder: user.SORT_ORDER,
  //     codeNo: user.CODE_NO,
  //   };
  //   setDeleteData(formValues);
  //   console.log('deleteDataForm', deleteDataForm)
  // }

  // const deleteData = async(event, user) => {
  //   setLoading(true)
  //   setDelete(event, user);
  //   console.log('deleteDataForm', deleteDataForm)
  //   const url = `https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api`
  //   const body = {
  //     function: "delete",
  //     FIELD_NAME: user.FIELD_NAME,
  //     CODE: user.CODE,
  //     LONG_DESCR: user.LONG_DESCR,
  //     SHORT_DESCR: user.SHORT_DESCR,
  //     NOTES: user.NOTES,
  //     SORT_ORDER: user.SORT_ORDER,
  //     CODE_NO: user.CODE_NO,
  //   } 
  //   console.log('deleteData body: ', body)
  //   return axios.put(url, body)
  //   .then(function (response) {
  //     console.log('DELETE Function Triggered: ', response);
      
  //     setLoading(false)
  //   })
  //   .catch(function (error) {
  //     console.log('Delete function error: ', error);
  //   });
  // }

  // const handleCancelClick = () => {
  //   setEditFormData({id: null});
  // }

  // const handleTableSelect = (e) => {
  //   console.log(e.target.value);
  //   setTableOption(e.target.value);
  // };

  // const getTableData = async() => {
  //   console.log('tableOption: ', tableOption)
  // }

  // const handleSearchChange = (e) => {
  //   e.preventDefault();
  //   if (e.target.value == "") {
  //     setData(allData)
  //   }
  //   else {
  //     const _data = allData.filter(item => item[filterOption].includes(e.target.value))
  //     setData(_data);
  //   }
  // };



  // const handlePageNumSelect = (e) => {
  //   console.log('e: ', e)
  //   setCurrentPageNumber(e);
  //   initPagination();
  // };


  // const initPagination = () => {

  //   console.log('currentPage: ', currentPage)
  //   console.log('currentPageNumber: ', currentPageNumber)
  //   // number of records to be displayed on each page
  //   // const [recordsPerPage] = useState(10);

  //   const indexOfLastRecord = currentPage * currentPageNumber;
  //   const indexOfFirstRecord = indexOfLastRecord - currentPageNumber;

  //   console.log('indexOfLastRecord: ', indexOfLastRecord)
  //   console.log('indexOfFirstRecord: ', indexOfFirstRecord)
  //   // Records to be displayed on the current page
  //   setCurrentRecords(allData.slice(indexOfFirstRecord, indexOfLastRecord));

  //   console.log('currentRecords: ', currentRecords)
  //   // Calculate number of pages
  //   setNPages(Math.ceil(allData.length / currentPageNumber));
  //   console.log('nPages: ', nPages)
  // };

  return (
    <div className="container">
      <div className="table-responsive">
        {loading ? <div className="bg"><div className="loader">Loading...</div></div> : ''}

        <h1 id="title">Snowflake Dashboard v6.0</h1> <br/>
        
        
        <form>
          <select value={selectedTable} onChange={e => setSelectedTable(e.target.value)}>
            {tableOptions.map((value) => (
              <option value={value} key={value}> {value} </option>
            ))}
          </select>
          <button type='button' onClick={getTable}>Select</button>
        </form> <br/>
        

        <AddRow handleAddFormChange={handleAddFormChange} postAddData={postAddData}/> <br/>

        <Table
          data={filtiredData}
          onEdit={onEdit}
          onDelete={onDelete}
          onFilter={onFilter}
          onFilterTagsChange={onFilterTagsChange}
        ></Table> 
        

        
      </div>
    </div>
  );
};

export default App;




        {/* <AddRow handleAddFormChange={handleAddFormChange} postAddData={postAddData}/> */}

        {/* <br></br> */}
        {/* <table id="users">
          <thead>
            {data.length ? <tr>
              <th>Rows</th>
              <th>FIELD_NAME</th>
              <th>CODE</th>
              <th>LONG_DESCR</th>
              <th>SHORT_DESCR</th>
              <th>NOTES</th>
              <th>SORT_ORDER</th>
              <th>CODE_NO</th>
            </tr> : <tr><th>No Data Found</th></tr>}
          </thead>
          <tbody>
            {currentRecords.map((user) => (
              <Fragment key={user.ID}>
              {editFormData.id === user.ID ? (
                <EditableRow
                  editFormData={editFormData}
                  handleEditFormChange={handleEditFormChange}
                  postData={postData}
                  handleCancelClick={handleCancelClick}
                />
              ) : (
                <ReadOnlyRow
                  user={user}
                  handleEditClick={handleEditClick}
                  deleteData={deleteData}
                />
              )}
            </Fragment>
            ))}
          </tbody>
        </table> */}