// import React, { useState } from "react";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faEdit, faTrash } from "@fortawesome/free-solid-svg-icons"

// export const GetTable = ({ getTableData }) => {
//   return (
//       <>
//         <form>
//             <label htmlFor="tableName">Choose a table: </label>
//             <select name="tables" id="tables">
//                 <option value="eds.core_base.domain_lookup">eds.core_base.domain_lookup</option>
//                 <option value="esdl.etl.data_classification_exception">esdl.etl.data_classification_exception</option>
//             </select>
//             <input type="submit" onClick={getTableData} value="Load"></input>
//             {/* <button type="button" onClick={getTableData}>Add</button> */}
//         </form>
//       </>
//   );
// };