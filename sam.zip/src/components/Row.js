import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faSave, faCancel } from "@fortawesome/free-solid-svg-icons"
import { DeleteButton } from "./DeleteButton";
import axios from 'axios';

export const Row = (props) => {
    const row = props.data;
    const [mode, setMode] = useState('readOnly');
    const [inputData, setInputData] = useState();

    const onSave = async () => {
        const newRow = {...row, ...inputData};
        const response = await props.onEdit({
            oldRow: row,
            newRow: newRow
        });
        console.log('inputData: ', inputData)
        console.log('row: ', row.FIELD_NAME)
        console.log('newRow: ', newRow)
        if (!response) {
            alert('Failed. Please check your connection and try again.')
        }
        setMode('readOnly');
    }

    const onDelete = async () => {
        // TODO are you sure alert

        const response = await props.onDelete(row);
        if (!response) {
            alert('Failed. Please check your connection and try again.')
        }
    }

    const onCancel = () => {
        setInputData(null);
        setMode('readOnly');
    }

    const onChange = (rowName, event) => {
        const value = event.target.value;
        switch (rowName) {
            case 'ID':
                // TODO validate ID
                setInputData({...inputData, ID: value});
                break;
            case 'FIELD_NAME':
                // TODO validate FIELD_NAME
                setInputData({...inputData, FIELD_NAME: value});
                break;
            case 'CODE':
                // TODO validate CODE
                setInputData({...inputData, CODE: value});
                break;
            case 'LONG_DESCR':
                // TODO validate LONG_DESCR
                setInputData({...inputData, LONG_DESCR: value});
                break;
            case 'SHORT_DESCR':
                // TODO validate SHORT_DESCR
                setInputData({...inputData, SHORT_DESCR: value});
                break;
            case 'NOTES':
                // TODO validate NOTES
                setInputData({...inputData, NOTES: value});
                break;
            case 'SORT_ORDER':
                // TODO validate SORT_ORDER
                setInputData({...inputData, SORT_ORDER: value});
                break;
            case 'CODE_NO':
                // TODO validate CODE_NO
                setInputData({...inputData, CODE_NO: value});
                break;
        }
    }

    return (
        <tr>
            {
                mode === 'readOnly' ?
                <>
                    <td>{row.ID}</td>
                    <td>{row.FIELD_NAME}</td>
                    <td>{row.CODE}</td>
                    <td>{row.LONG_DESCR}</td>
                    <td>{row.SHORT_DESCR}</td>
                    <td>{row.NOTES}</td>
                    <td>{row.SORT_ORDER}</td>
                    <td>{row.CODE_NO}</td>
                    <td className="action-btns">
                        <button type="button" className="btn btn-light" onClick={() => setMode('editable')}>
                            <FontAwesomeIcon icon={faEdit} />
                        </button>

                        <DeleteButton data={row} deleteData={() => onDelete()}></DeleteButton>
                    </td>
                </> :
                <>
                    <td>
                        <input
                        type="text"
                        required="required"
                        name="id"
                        value={row.ID}
                        disabled
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required="required"
                        placeholder="Enter field name..."
                        name="fieldName"
                        defaultValue={row.FIELD_NAME}
                        onChange={(event) => onChange('FIELD_NAME', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required="required"
                        placeholder="Enter code..."
                        name="code"
                        defaultValue={row.CODE}
                        onChange={(event) => onChange('CODE', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required=""
                        placeholder="Enter a long description..."
                        name="longDesc"
                        defaultValue={row.LONG_DESCR}
                        onChange={(event) => onChange('LONG_DESCR', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required=""
                        placeholder="Enter a short description..."
                        name="shortDesc"
                        defaultValue={row.SHORT_DESCR}
                        onChange={(event) => onChange('SHORT_DESCR', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required=""
                        placeholder="Enter notes..."
                        name="notes"
                        defaultValue={row.NOTES}
                        onChange={(event) => onChange('NOTES', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required=""
                        placeholder="Enter sort order..."
                        name="sortOrder"
                        defaultValue={row.SORT_ORDER}
                        onChange={(event) => onChange('SORT_ORDER', event)}
                        ></input>
                    </td>
                    <td>
                        <input
                        type="text"
                        required=""
                        placeholder="Enter code no..."
                        name="codeNo"
                        defaultValue={row.CODE_NO}
                        onChange={(event) => onChange('CODE_NO', event)}
                        ></input>
                    </td>
                    <td className="action-btns">
                        <button type="button" className="btn btn-light">
                            <FontAwesomeIcon icon={faSave} onClick={onSave}/>
                        </button>

                        <button type="button" className="btn btn-light">
                            <FontAwesomeIcon icon={faCancel} onClick={onCancel}/>
                        </button>
                    </td>
                </>
            }
        </tr>

    );
};