import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import '../styles/delete.css';

export const DeleteModal = ({ data, deleteData, onHide }) => {
  const [show, setShow] = useState(false);

  const handleClose = () => {
    setShow(false)
    onHide()
  };
  const handleShow = () => setShow(true);
  const modalToggle = (bool) => setShow(bool);

  return (
    <>
      <Button variant="primary" onClick={handleShow}> DELETE </Button>

      <Modal
        dialogClassName="delete-modal"
        show={show}
        onHide={handleClose}
        // onHide={() => modalToggle(false)}
        backdrop={false}
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Permanently Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h2>Are you SURE you want to delete? This will PERMANENTLY DELETE row:</h2>
          
          <table>
            <tbody>
              <tr>
                <td>
                  Row<br></br>{data.ID}
                </td>
                <td>
                  FIELD_NAME<br></br>{data.FIELD_NAME}
                </td>
                <td>
                  CODE<br></br>{data.CODE}
                </td>
                <td>
                  LONG_DESCR<br></br>{data.LONG_DESCR}
                </td>
                <td>
                  SHORT_DESCR<br></br>{data.SHORT_DESCR}
                </td>
                <td>
                  NOTES<br></br>{data.NOTES}
                </td>
                <td>
                  SORT_ORDER<br></br>{data.SORT_ORDER}
                </td>
                <td>
                  CODE_NO<br></br>{data.CODE_NO}
                </td>
              </tr>
            </tbody>
          </table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={(event) => {deleteData(event, data); handleClose();}}>PERMANENTLY DELETE</Button>

        </Modal.Footer>
      </Modal>
    </>
  );
}