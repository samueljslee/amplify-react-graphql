import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { DeleteModal } from './DeleteModal';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons"
import '../styles/delete.css';

export const DeleteButton = ({ data, deleteData }) => {
  const [show, setShow] = useState(false);
  const modalToggle = (bool) => setShow(bool);

  return (
    <>
      <button type="button" className="btn btn-light" onClick={() => modalToggle(true)}>
        <FontAwesomeIcon icon={faTrash} />
      </button>

      <Modal
        show={show}
        onHide={() => modalToggle(false)}
        backdrop="static"
        keyboard={false}
        dialogClassName="delete-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title>Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h3>Are you sure you want to delete?</h3>
          <table>
            <tbody>
              <tr>
                <td>
                  Row<br></br>{data.ID}
                </td>
                <td>
                  FIELD_NAME<br></br>{data.FIELD_NAME}
                </td>
                <td>
                  CODE<br></br>{data.CODE}
                </td>
                <td>
                  LONG_DESCR<br></br>{data.LONG_DESCR}
                </td>
                <td>
                  SHORT_DESCR<br></br>{data.SHORT_DESCR}
                </td>
                <td>
                  NOTES<br></br>{data.NOTES}
                </td>
                <td>
                  SORT_ORDER<br></br>{data.SORT_ORDER}
                </td>
                <td>
                  CODE_NO<br></br>{data.CODE_NO}
                </td>
              </tr>
            </tbody>
          </table>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => modalToggle(false)}> Close </Button>
          <DeleteModal data={data} deleteData={deleteData} onHide={() => modalToggle(false)}></DeleteModal>
        </Modal.Footer>
      </Modal>
    </>
  );
}