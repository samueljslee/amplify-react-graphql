// import React, { useState } from 'react';
// import Button from 'react-bootstrap/Button';
// import Modal from 'react-bootstrap/Modal';
// import { PermDeleteModal } from '../components';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faTrash } from "@fortawesome/free-solid-svg-icons"

// export const WarningDeleteModal = ({ user, deleteData }) => {
//   const [show, setShow] = useState(false);

//   const modalToggle = (bool) => setShow(bool);

//   return (
//     <>
//       <button type="button" onClick={() => modalToggle(true)}>
//         <FontAwesomeIcon icon={faTrash} />
//       </button>

//       <Modal
//         show={show}
//         onHide={() => modalToggle(false)}
//         backdrop="static"
//         keyboard={false}
//       >
//         <Modal.Header closeButton>
//           <Modal.Title>Delete</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           Are you sure you want to delete?
//           <p>
//             id: {user.ID} <br></br> 
//             field_name: {user.FIELD_NAME} <br></br> 
//             code: {user.CODE} <br></br> 
//             long_descr: {user.LONG_DESCR} <br></br> 
//             short_descr: {user.SHORT_DESCR} <br></br> 
//             notes: {user.NOTES} <br></br> 
//             sort_order: {user.SORT_ORDER} <br></br> 
//             code_no: {user.CODE_NO} <br></br> 
//           </p>
         
//         </Modal.Body>

//         <Modal.Footer>
          
//           <Button variant="secondary" onClick={() => modalToggle(false)}> Close </Button>
//           <PermDeleteModal user={user} deleteData={deleteData} onHide={() => modalToggle(false)}/>

//         </Modal.Footer>
//       </Modal>
//     </>
//   );
// }

