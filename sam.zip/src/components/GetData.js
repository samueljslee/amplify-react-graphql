// import React from 'react';
// import axios from 'axios';

// export default class GetData extends React.Component {
//     state = {
//         data: []
//     }

//     componentDidMount() {
//         axios.get('https://vf680oho9e.execute-api.us-east-1.amazonaws.com/dev/sf_poc_api')
//             .then(res => {
//                 const datas = res.data;
//                 this.setState({datas});
//             })
//     }

//     render() {
//         return (
//             <ul>
//                 {
//                     this.state.datas
//                         .map(data => 
//                             <li key={data.FIELD_NAME}>{data.name}</li>
//                         )
//                 }
//             </ul>
//         )
//     }
// }