import React, { useEffect, useState } from 'react';
import { Row } from './Row';
import '../styles/pagination.css';
import 'bootstrap/dist/js/bootstrap';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";

export const Table = (props) => {
    const [recordsPerPage, setRecordsPerPage] = useState(5);
    const [visibleRecords, setVisibleRecords] = useState([]);
    const [activePage, setActivePage] = useState(1);
    const [pageCount, setPageCount] = useState(0);
    const [filterName, setFilterName] = useState('Filter');
    const [filterInput, setFilterInput] = useState('');
    const [filterTags, setFilterTags] = useState([]);

    useEffect(() => {
        const _pageCount = Math.ceil(props.data.length / recordsPerPage);

        setPageCount(_pageCount);

        let _records = {};
        for (let i = 0; i < _pageCount; i++) {
            _records[i + 1] = props.data.slice(i * recordsPerPage, i * recordsPerPage + recordsPerPage);
        }

        setVisibleRecords(_records[activePage]);
    }, [props.data, recordsPerPage, activePage, pageCount]);

    useEffect(() => {
        setActivePage(1);
    }, [filterName]);

    useEffect(() => {
        if(filterInput === '') {
            setActivePage(1);
        }
    }, [filterInput]);

    const onRecordsPerPageChange = (num) => {
        setRecordsPerPage(num);
        setActivePage(1);
    }

    const onFilterInput = (_filterInput) => {
        props.onFilter();
        if (_filterInput) {
            props.onFilter({ filterInput: _filterInput, filterName });
        } else {
            props.onFilter();
        }
        setFilterInput(_filterInput)
    }

    const onFilterChange = (filterName) => {
        props.onFilter();
        setFilterName(filterName);
        setFilterInput('');
    }

    const nextPage = () => {
        if (pageCount > activePage) {
            setActivePage(activePage + 1);
        } else {
            console.log('nextButton is not Active');
        }
    }

    const prevPage = () => {
        if (activePage > 1) {
            setActivePage(activePage - 1);
        } else {
            console.log('prevButton is not Active');
        }
    }

    const saveFilter = () => {
        const _filterTags = [...filterTags, { filterName, filterInput }];
        setFilterTags(_filterTags);
        setFilterInput('');
    }

    const removeFilterTag = (filter) => {
        const _filterTags = filterTags.filter(f => f.filterName !== filter.filterName && f.filterInput !== filter.filterInput);
        setFilterTags(_filterTags);
    }

    useEffect(() => props.onFilterTagsChange(filterTags), [filterTags]);

    return (
        <>
            <div className="add-btn">
                <button type="button" className="btn btn-light">Add a record</button>
            </div>

            <div className="dropdown filter">
                <button className="btn btn-light dropdown-toggle" type="button" id="filter" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    {filterName}
                </button>
                <div className="dropdown-menu" aria-labelledby="filter">
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('Filter')}>None</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('ID')}>Row</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('FIELD_NAME')}>FIELD_NAME</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('CODE')}>CODE</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('LONG_DESCR')}>LONG_DESCR</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('SHORT_DESCR')}>SHORT_DESCR</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('NOTES')}>NOTES</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('SORT_ORDER')}>SORT_ORDER</a>
                    <a className="dropdown-item" href="#" onClick={(e) => onFilterChange('CODE_NO')}>CODE_NO</a>
                </div>
            </div>

            <div className={filterName !== 'Filter' ? "filter-input visible" : "filter-input"}>
                <input
                    type="text"
                    className="form-control"
                    placeholder={'Input ' + filterName}
                    aria-label="Filter"
                    aria-describedby="basic-addon1"
                    value={filterInput}
                    onChange={(e) => onFilterInput(e.target.value)}>
                </input>
            </div>
            <div className={filterName !== 'Filter' && filterInput ? "plus-btn visible" : "plus-btn"}>
                <button type="button" className="btn btn-light" onClick={() => saveFilter()}>
                    <FontAwesomeIcon icon={faPlus} />
                </button>
            </div>
            <div className="filter-tag">
                {filterTags.map((ft, index) => {
                    return <span key={filterName + index} onClick={() => removeFilterTag(ft)}>{ft.filterName} = {ft.filterInput}</span>
                })}
            </div>
            <br />
            <br />
            <p className="records-info">Records: <span>{props.data.length}</span></p>

            <table className="table table-striped" id="table">
                <thead>
                    <tr>
                        {visibleRecords && visibleRecords.length ?
                            <>
                                <th>Row</th>
                                <th>FIELD_NAME</th>
                                <th>CODE</th>
                                <th>LONG_DESCR</th>
                                <th>SHORT_DESCR</th>
                                <th>NOTES</th>
                                <th>SORT_ORDER</th>
                                <th>CODE_NO</th>
                                <th>Actions</th>
                            </> :
                            <th>No Data Found</th>
                        }
                    </tr>
                </thead>
                <tbody>
                    { visibleRecords && visibleRecords.length ?
                        visibleRecords.map((row) => {
                            return <Row
                                key={JSON.stringify(row)}
                                data={row}
                                onEdit={props.onEdit}
                                onDelete={props.onDelete}
                            ></Row>
                        }) : <></>
                    }
                </tbody>
            </table>

            <br />

            <div className="dropdown items-per-page">
                <button className="btn btn-light dropdown-toggle" type="button" id="items-per-page" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    {recordsPerPage}
                </button>
                <div className="dropdown-menu" aria-labelledby="items-per-page">
                    <a className="dropdown-item" href="#" onClick={() => onRecordsPerPageChange(5)}>5</a>
                    <a className="dropdown-item" href="#" onClick={() => onRecordsPerPageChange(15)}>15</a>
                    <a className="dropdown-item" href="#" onClick={() => onRecordsPerPageChange(50)}>50</a>
                    <a className="dropdown-item" href="#" onClick={() => onRecordsPerPageChange(1000)}>1000</a>
                </div>
            </div>
            <nav aria-label="Page navigation">
                <ul className="pagination">
                    <li className="page-item">
                        <a className="page-link" href="#" aria-label="Previous" onClick={prevPage}>
                            <span aria-hidden="true">&larr;</span>
                        </a>
                    </li>
                    <li className="page-item">
                        <button className="btn btn-light current-page-info">{activePage} / {pageCount}</button>
                    </li>
                    <li className="page-item">
                        <a className="page-link" href="#" aria-label="Next" onClick={nextPage}>
                            <span aria-hidden="true">&rarr;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </>
    )
};
