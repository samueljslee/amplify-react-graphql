import React from "react";

const AddRow = ({ handleAddFormChange, postAddData }) => { return (
    <>
        <br></br>

        <h3> Add Row </h3>
        <table>
            <tbody>
                <tr>
                    <td> <input type="text" name="fieldName" required="" placeholder="Enter FIELD_NAME..." onChange={handleAddFormChange}/> </td>

                    <td> <input type="text" name="code" required="" placeholder="Enter CODE..." onChange={handleAddFormChange}/> </td>

                    <td> <input type="text" name="longDesc" required="" placeholder="Enter LONG_DESCR..." onChange={handleAddFormChange}/> </td>

                    <td> <input type="text" name="shortDesc" required="" placeholder="Enter SHORT_DESCR..." onChange={handleAddFormChange}/> </td>

                    <td> <input type="text" name="notes" required="" placeholder="Enter NOTES..." onChange={handleAddFormChange}/>  </td> 
                    
                    <td>
                        <input
                            type="text"
                            name="sortOrder"
                            required=""
                            placeholder="Enter SORT_ORDER..."
                            onChange={handleAddFormChange}
                        />
                    </td>

                    <td>
                        <input
                            type="text"
                            name="codeNo"
                            required=""
                            placeholder="Enter CODE_NO..."
                            onChange={handleAddFormChange}
                        />
                    </td>

                    <td>
                        <button type="button" onClick={postAddData}>Add</button>
                    </td>

                </tr>
            </tbody>
        </table>
      </>
    );
};

export default AddRow;