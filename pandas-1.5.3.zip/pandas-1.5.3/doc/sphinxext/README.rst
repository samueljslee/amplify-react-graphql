sphinxext
=========

This directory contains custom sphinx extensions in use in the pandas
documentation.
